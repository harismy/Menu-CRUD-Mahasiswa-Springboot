package com.example.model;

public class Mahasiswa{
    String nama, npm, prodi;
    Double ipk;
   
   public Mahasiswa(){
        
    }
   public Mahasiswa(String nama, String npm, String prodi, Double ipk){
        this.nama = nama;
        this.npm = npm;
        this.prodi = prodi;
        this.ipk = ipk;
    }
    public void TampilData(){
        System.out.println("Nama : "+nama);
        System.out.println("NPM  : "+npm);
        System.out.println("Prodi: "+prodi);
        System.out.println("IPK  : "+ipk);
    }
    @Override
    public String toString() {
        return "Nama : " + nama + "\n" +
               "NPM  : " + npm + "\n" +
               "Prodi: " + prodi + "\n" +
               "IPK  : " + ipk + "\n";
    }
    public String getNama(){
        return nama;
    }
    public void setNama(String nama){
        this.nama = nama;
    }
    public String getNpm(){
    return npm;
    }
    public void setNpm(String npm){
        this.npm = npm;
    }
    public String getProdi(){
        return prodi;
    }
    public void setProdi(String prodi){
        this.prodi = prodi;
    }
    public Double getIpk(){
        return ipk;
    }
    public void setIpk(Double ipk){
        this.ipk = ipk;
    }
    
}