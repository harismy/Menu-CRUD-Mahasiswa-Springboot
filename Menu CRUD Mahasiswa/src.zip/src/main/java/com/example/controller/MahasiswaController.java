package com.example.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.model.Mahasiswa;

@Controller
@RequestMapping("/mahasiswa")
public class MahasiswaController {
    private List<Mahasiswa> dataMahasiswa = new ArrayList<>();

    // Menampilkan daftar mahasiswa
    @GetMapping("/list")
    public String tampilkanMahasiswa(Model model) {
        model.addAttribute("mahasiswaList", dataMahasiswa);
        return "mahasiswa";
    }

    // Menampilkan form tambah
    @GetMapping("/tambah")
    public String formTambah(Model model) {
        model.addAttribute("mahasiswa", new Mahasiswa());
        return "tambah";
    }

    // Menyimpan mahasiswa baru
    @PostMapping("/tambah")
    public String simpanMahasiswa(@ModelAttribute Mahasiswa mahasiswa) {
        dataMahasiswa.add(mahasiswa);
        return "redirect:/mahasiswa";
    }

    // Menampilkan form edit berdasarkan NIM
    @GetMapping("/edit/{nim}")
    public String formEdit(@PathVariable String nim, Model model) {
        Mahasiswa mhs = cariMahasiswaByNim(nim);
        model.addAttribute("mahasiswa", mhs);
        return "edit";
    }

    // Simpan hasil edit
    @PostMapping("/edit")
    public String simpanEdit(@ModelAttribute Mahasiswa mahasiswa) {
        Mahasiswa existing = cariMahasiswaByNim(mahasiswa.getNpm());
        if (existing != null) {
            existing.setNama(mahasiswa.getNama());
            existing.setProdi(mahasiswa.getProdi());
        }
        return "redirect:/mahasiswa";
    }

    // Hapus mahasiswa berdasarkan NIM
    @GetMapping("/hapus/{nim}")
    public String hapusMahasiswa(@PathVariable String nim) {
        Mahasiswa mhs = cariMahasiswaByNim(nim);
        if (mhs != null) {
            dataMahasiswa.remove(mhs);
        }
        return "redirect:/mahasiswa";
    }

    // Util: cari mahasiswa berdasarkan NIM
    private Mahasiswa cariMahasiswaByNim(String nim) {
        for (Mahasiswa m : dataMahasiswa) {
            if (m.getNpm().equals(nim)) {
                return m;
            }
        }
        return null;
    }
}