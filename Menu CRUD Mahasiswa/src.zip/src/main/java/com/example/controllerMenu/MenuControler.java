package com.example.controllerMenu;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MenuControler {
    @GetMapping("/")
    public String tampilanMenu(){
        return "menu";
    }
}
